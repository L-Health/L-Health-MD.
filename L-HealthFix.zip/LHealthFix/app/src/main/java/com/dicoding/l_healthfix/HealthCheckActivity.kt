package com.dicoding.l_healthfix

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class HealthCheckActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.health_check)

        val btnMulai: Button = findViewById(R.id.btn_mulai)
        btnMulai.setOnClickListener {
            Toast.makeText(this, "Memulai pemeriksaan kesehatan", Toast.LENGTH_SHORT).show()
        }
    }
}
