package com.dicoding.l_health

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.dicoding.l_healthfix.HealthCheckActivity
import com.dicoding.l_healthfix.R

class ProfileActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_profil)

        val profileImage: ImageView = findViewById(R.id.profileImage)
        val editProfileImage: ImageButton = findViewById(R.id.editProfileImage)
        val fullName: EditText = findViewById(R.id.fullName)
        val nickname: EditText = findViewById(R.id.nickname)
        val birthDate: EditText = findViewById(R.id.birthDate)
        val phoneNumber: EditText = findViewById(R.id.phoneNumber)
        val genderSpinner: Spinner = findViewById(R.id.genderSpinner)
        val continueButton: Button = findViewById(R.id.continueButton)

        val genderOptions = arrayOf("Laki-laki", "Perempuan", "Lainnya")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, genderOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        genderSpinner.adapter = adapter

        continueButton.setOnClickListener {
            val intent = Intent(this, HealthCheckActivity::class.java)
            startActivity(intent)
        }

        editProfileImage.setOnClickListener {
        }
    }
}
